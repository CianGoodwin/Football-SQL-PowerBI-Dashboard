-- SQLite
.schema